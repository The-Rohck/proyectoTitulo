import { Request, Response } from 'express';
import MiniGame from '../models/miniGame.model';

// Crear minijuego
export const createMiniGame = async (req: Request, res: Response) => {
  try {
    const game = new MiniGame(req.body);
    await game.save();
    res.status(201).json({ message: 'Mini-juego creado', game });
  } catch (error) {
    res.status(400).json({ message: 'Error al crear mini-juego', error });
  }
};

// Obtener todos los minijuegos
export const getMiniGames = async (_req: Request, res: Response) => {
  try {
    const games = await MiniGame.find();
    res.json(games);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener mini-juegos', error });
  }
};

// Obtener un minijuego
export const getMiniGameById = async (req: Request, res: Response) => {
  try {
    const game = await MiniGame.findById(req.params.id);
    if (!game) return res.status(404).json({ message: 'No encontrado' });
    res.json(game);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener mini-juego', error });
  }
};

// Actualizar minijuego
export const updateMiniGame = async (req: Request, res: Response) => {
  try {
    const game = await MiniGame.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!game) return res.status(404).json({ message: 'No encontrado' });
    res.json({ message: 'Mini-juego actualizado', game });
  } catch (error) {
    res.status(400).json({ message: 'Error al actualizar mini-juego', error });
  }
};

// Eliminar minijuego
export const deleteMiniGame = async (req: Request, res: Response) => {
  try {
    const game = await MiniGame.findByIdAndDelete(req.params.id);
    if (!game) return res.status(404).json({ message: 'No encontrado' });
    res.json({ message: 'Mini-juego eliminado' });
  } catch (error) {
    res.status(500).json({ message: 'Error al eliminar mini-juego', error });
  }
};
