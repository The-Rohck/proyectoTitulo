import { Request, Response } from 'express';
import Content from '../models/content.model';

// Crear contenido
export const createContent = async (req: Request, res: Response) => {
  try {
    const content = new Content(req.body);
    await content.save();
    res.status(201).json({ message: 'Contenido creado', content });
  } catch (error) {
    res.status(400).json({ message: 'Error al crear contenido', error });
  }
};

// Obtener todos los contenidos
export const getContents = async (_req: Request, res: Response) => {
  try {
    const contents = await Content.find();
    res.json(contents);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener contenidos', error });
  }
};

// Obtener un contenido por ID
export const getContentById = async (req: Request, res: Response) => {
  try {
    const content = await Content.findById(req.params.id);
    if (!content) return res.status(404).json({ message: 'No encontrado' });
    res.json(content);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener contenido', error });
  }
};

// Actualizar contenido
export const updateContent = async (req: Request, res: Response) => {
  try {
    const content = await Content.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!content) return res.status(404).json({ message: 'No encontrado' });
    res.json({ message: 'Contenido actualizado', content });
  } catch (error) {
    res.status(400).json({ message: 'Error al actualizar contenido', error });
  }
};

// Eliminar contenido
export const deleteContent = async (req: Request, res: Response) => {
  try {
    const content = await Content.findByIdAndDelete(req.params.id);
    if (!content) return res.status(404).json({ message: 'No encontrado' });
    res.json({ message: 'Contenido eliminado' });
  } catch (error) {
    res.status(500).json({ message: 'Error al eliminar contenido', error });
  }
};
