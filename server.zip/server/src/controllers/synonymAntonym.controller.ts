import { Request, Response } from 'express';
import SynonymAntonym from '../models/synonymAntonym.model';

// 📜 Obtener todos
export const getAllRelations = async (req: Request, res: Response) => {
  try {
    const relations = await SynonymAntonym.find().sort({ createdAt: -1 });
    res.json(relations);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener relaciones', error });
  }
};

// 🔍 Obtener por ID
export const getRelationById = async (req: Request, res: Response) => {
  try {
    const relation = await SynonymAntonym.findById(req.params.id);
    if (!relation) return res.status(404).json({ message: 'Relación no encontrada' });
    res.json(relation);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener relación', error });
  }
};

// ➕ Crear
export const createRelation = async (req: Request, res: Response) => {
  try {
    const relation = new SynonymAntonym(req.body);
    await relation.save();
    res.status(201).json({ message: 'Relación creada', relation });
  } catch (error) {
    res.status(400).json({ message: 'Error al crear relación', error });
  }
};

// 📝 Actualizar
export const updateRelation = async (req: Request, res: Response) => {
  try {
    const relation = await SynonymAntonym.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!relation) return res.status(404).json({ message: 'Relación no encontrada' });
    res.json({ message: 'Relación actualizada', relation });
  } catch (error) {
    res.status(400).json({ message: 'Error al actualizar relación', error });
  }
};

// ❌ Eliminar
export const deleteRelation = async (req: Request, res: Response) => {
  try {
    const relation = await SynonymAntonym.findByIdAndDelete(req.params.id);
    if (!relation) return res.status(404).json({ message: 'Relación no encontrada' });
    res.json({ message: 'Relación eliminada correctamente' });
  } catch (error) {
    res.status(500).json({ message: 'Error al eliminar relación', error });
  }
};
