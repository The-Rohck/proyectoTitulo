import { Request, Response } from 'express';
import Word from '../models/word.model';

// 📜 Obtener todas las palabras
export const getAllWords = async (req: Request, res: Response) => {
  try {
    const words = await Word.find().sort({ term: 1 });
    res.json(words);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener palabras', error });
  }
};

// 🔍 Obtener una palabra por ID
export const getWordById = async (req: Request, res: Response) => {
  try {
    const word = await Word.findById(req.params.id);
    if (!word) return res.status(404).json({ message: 'Palabra no encontrada' });
    res.json(word);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener palabra', error });
  }
};

// ➕ Crear palabra
export const createWord = async (req: Request, res: Response) => {
  try {
    const word = new Word(req.body);
    await word.save();
    res.status(201).json({ message: 'Palabra creada', word });
  } catch (error) {
    res.status(400).json({ message: 'Error al crear palabra', error });
  }
};

// 📝 Actualizar palabra
export const updateWord = async (req: Request, res: Response) => {
  try {
    const word = await Word.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!word) return res.status(404).json({ message: 'Palabra no encontrada' });
    res.json({ message: 'Palabra actualizada', word });
  } catch (error) {
    res.status(400).json({ message: 'Error al actualizar palabra', error });
  }
};

// ❌ Eliminar palabra
export const deleteWord = async (req: Request, res: Response) => {
  try {
    const word = await Word.findByIdAndDelete(req.params.id);
    if (!word) return res.status(404).json({ message: 'Palabra no encontrada' });
    res.json({ message: 'Palabra eliminada correctamente' });
  } catch (error) {
    res.status(500).json({ message: 'Error al eliminar palabra', error });
  }
};
