import { Request, Response } from 'express';
import GameSession from '../models/gameSession.model';
import Word from '../models/content.model';
import { AuthRequest } from '../middlewares/auth.middleware';

// 🎬 Iniciar juego
export const startGame = async (req: AuthRequest, res: Response) => {
  try {
    const words = await Word.aggregate([{ $sample: { size: 5 } }]); // 5 palabras aleatorias
    const letters = words.map((w: any) => ({
      wordId: w._id,
      letter: w.word.charAt(0).toUpperCase(),
      definition: w.meaning,
      correctAnswer: w.word,
    }));

    const session = new GameSession({
      user: req.user?.id,
      letters,
      score: 0,
      timeLeft: 60,
    });
    await session.save();

    res.status(201).json({ message: 'Sesión iniciada', data: session });
  } catch (error) {
    res.status(500).json({ message: 'Error al iniciar juego', error });
  }
};

// ✍️ Enviar respuesta
export const submitAnswer = async (req: AuthRequest, res: Response) => {
  try {
    const { sessionId, index, answer } = req.body;
    const session = await GameSession.findById(sessionId);
    if (!session) return res.status(404).json({ message: 'Sesión no encontrada' });

    const letter = session.letters[index];
    if (!letter) return res.status(400).json({ message: 'Índice inválido' });

    if (letter.status !== 'pending')
      return res.status(400).json({ message: 'Esta palabra ya fue respondida' });

    if (letter.correctAnswer.toLowerCase() === answer.toLowerCase()) {
      letter.status = 'correct';
      session.score += 10;
    } else {
      letter.status = 'wrong';
      session.score -= 2;
    }

    await session.save();
    res.json({ message: 'Respuesta registrada', data: session });
  } catch (error) {
    res.status(500).json({ message: 'Error al enviar respuesta', error });
  }
};

// 🏁 Finalizar juego
export const endGame = async (req: AuthRequest, res: Response) => {
  try {
    const { sessionId } = req.body;
    const session = await GameSession.findById(sessionId);
    if (!session) return res.status(404).json({ message: 'Sesión no encontrada' });

    session.finished = true;
    await session.save();

    res.json({ message: 'Juego finalizado', finalScore: session.score });
  } catch (error) {
    res.status(500).json({ message: 'Error al finalizar juego', error });
  }
};

// 📜 Historial del jugador
export const getUserGames = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user?.id;
    const games = await GameSession.find({ user: userId }).sort({ createdAt: -1 });
    res.json(games);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener historial', error });
  }
};
