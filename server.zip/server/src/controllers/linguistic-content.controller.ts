import { Request, Response } from 'express';
import LinguisticContent from '../models/linguistic-content.model';

// Crear
export const createLinguisticContent = async (req: Request, res: Response) => {
  try {
    const item = new LinguisticContent(req.body);
    await item.save();
    res.status(201).json({ message: 'Contenido lingüístico creado', item });
  } catch (error) {
    res.status(400).json({ message: 'Error al crear contenido', error });
  }
};

// Listar
export const getLinguisticContents = async (_req: Request, res: Response) => {
  try {
    const items = await LinguisticContent.find();
    res.json(items);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener contenidos', error });
  }
};

// Obtener por ID
export const getLinguisticContentById = async (req: Request, res: Response) => {
  try {
    const item = await LinguisticContent.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'No encontrado' });
    res.json(item);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener contenido', error });
  }
};

// Actualizar
export const updateLinguisticContent = async (req: Request, res: Response) => {
  try {
    const item = await LinguisticContent.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!item) return res.status(404).json({ message: 'No encontrado' });
    res.json({ message: 'Contenido actualizado', item });
  } catch (error) {
    res.status(400).json({ message: 'Error al actualizar contenido', error });
  }
};

// Eliminar
export const deleteLinguisticContent = async (req: Request, res: Response) => {
  try {
    const item = await LinguisticContent.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ message: 'No encontrado' });
    res.json({ message: 'Contenido eliminado' });
  } catch (error) {
    res.status(500).json({ message: 'Error al eliminar contenido', error });
  }
};
