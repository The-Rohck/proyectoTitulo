import { Request, Response } from 'express';
import Phrase from '../models/phrase.model';

// 📜 Obtener todas las frases
export const getPhrases = async (req: Request, res: Response) => {
  try {
    const phrases = await Phrase.find().sort({ createdAt: -1 });
    res.json(phrases);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener frases', error });
  }
};

// 🔍 Obtener frase por ID
export const getPhraseById = async (req: Request, res: Response) => {
  try {
    const phrase = await Phrase.findById(req.params.id);
    if (!phrase) return res.status(404).json({ message: 'Frase no encontrada' });
    res.json(phrase);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener frase', error });
  }
};

// ➕ Crear nueva frase
export const createPhrase = async (req: Request, res: Response) => {
  try {
    const phrase = new Phrase(req.body);
    await phrase.save();
    res.status(201).json({ message: 'Frase creada', phrase });
  } catch (error) {
    res.status(400).json({ message: 'Error al crear frase', error });
  }
};

// 📝 Actualizar frase
export const updatePhrase = async (req: Request, res: Response) => {
  try {
    const phrase = await Phrase.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!phrase) return res.status(404).json({ message: 'Frase no encontrada' });
    res.json({ message: 'Frase actualizada', phrase });
  } catch (error) {
    res.status(400).json({ message: 'Error al actualizar frase', error });
  }
};

// ❌ Eliminar frase
export const deletePhrase = async (req: Request, res: Response) => {
  try {
    const phrase = await Phrase.findByIdAndDelete(req.params.id);
    if (!phrase) return res.status(404).json({ message: 'Frase no encontrada' });
    res.json({ message: 'Frase eliminada correctamente' });
  } catch (error) {
    res.status(500).json({ message: 'Error al eliminar frase', error });
  }
};
