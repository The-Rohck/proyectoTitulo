import { Request, Response } from 'express';
import GameSession from '../models/gameSession.model';
import User from '../models/user.model';

// 📊 Reporte general de desempeño (solo admin)
export const getGeneralStats = async (req: Request, res: Response) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalGames = await GameSession.countDocuments();

    const avgScore = await GameSession.aggregate([
      { $group: { _id: null, avg: { $avg: '$score' } } },
    ]);

    const gameTypeStats = await GameSession.aggregate([
      { $group: { _id: '$gameType', count: { $sum: 1 }, avgScore: { $avg: '$score' } } },
    ]);

    res.json({
      totalUsers,
      totalGames,
      averageScore: avgScore[0]?.avg || 0,
      gameTypeStats,
    });
  } catch (error) {
    res.status(500).json({ message: 'Error al generar estadísticas generales', error });
  }
};

// 📈 Reporte del jugador autenticado
export const getUserStats = async (req: any, res: Response) => {
  try {
    const userId = req.user?.id;

    const games = await GameSession.find({ userId });
    if (!games.length)
      return res.json({ message: 'Sin partidas registradas', stats: null });

    const totalGames = games.length;
    const totalScore = games.reduce((sum, g) => sum + g.score, 0);
    const avgScore = totalScore / totalGames;

    const byType = games.reduce((acc: any, g) => {
      acc[g.gameType] = acc[g.gameType] || { games: 0, avgScore: 0 };
      acc[g.gameType].games++;
      acc[g.gameType].avgScore += g.score;
      return acc;
    }, {});

    for (const type in byType) {
      byType[type].avgScore /= byType[type].games;
    }

    res.json({
      totalGames,
      averageScore: avgScore,
      byType,
    });
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener estadísticas del jugador', error });
  }
};

// 🏆 Ranking global (top 10)
export const getLeaderboard = async (req: Request, res: Response) => {
  try {
    const leaderboard = await GameSession.aggregate([
      {
        $group: {
          _id: '$userId',
          totalScore: { $sum: '$score' },
          gamesPlayed: { $sum: 1 },
        },
      },
      { $sort: { totalScore: -1 } },
      { $limit: 10 },
      {
        $lookup: {
          from: 'users',
          localField: '_id',
          foreignField: '_id',
          as: 'user',
        },
      },
      { $unwind: '$user' },
      {
        $project: {
          _id: 0,
          username: '$user.username',
          totalScore: 1,
          gamesPlayed: 1,
        },
      },
    ]);

    res.json(leaderboard);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener ranking', error });
  }
};
