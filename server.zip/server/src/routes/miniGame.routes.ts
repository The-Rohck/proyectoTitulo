import express from 'express';
import {
  createMiniGame,
  getMiniGames,
  getMiniGameById,
  updateMiniGame,
  deleteMiniGame,
} from '../controllers/miniGame.controller';
import { verifyToken, isAdmin } from '../middlewares/auth.middleware';

const router = express.Router();

// Rutas: CRUD administrado
router.post('/', verifyToken, isAdmin, createMiniGame);
router.get('/', getMiniGames);
router.get('/:id', getMiniGameById);
router.put('/:id', verifyToken, isAdmin, updateMiniGame);
router.delete('/:id', verifyToken, isAdmin, deleteMiniGame);

export default router;
