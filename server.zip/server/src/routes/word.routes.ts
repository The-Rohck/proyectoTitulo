import express from 'express';
import {
  getAllWords,
  getWordById,
  createWord,
  updateWord,
  deleteWord,
} from '../controllers/word.controller';
import { verifyToken, isAdmin } from '../middlewares/auth.middleware';

const router = express.Router();

// Rutas públicas para usuarios autenticados
router.get('/', verifyToken, getAllWords);
router.get('/:id', verifyToken, getWordById);

// Rutas exclusivas para administradores
router.post('/', verifyToken, isAdmin, createWord);
router.put('/:id', verifyToken, isAdmin, updateWord);
router.delete('/:id', verifyToken, isAdmin, deleteWord);

export default router;
