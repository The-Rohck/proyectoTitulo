import express from 'express';
import {
  startGame,
  submitAnswer,
  endGame,
  getUserGames,
} from '../controllers/game.controller';
import { verifyToken } from '../middlewares/auth.middleware';

const router = express.Router();

router.post('/start', verifyToken, startGame);
router.post('/answer', verifyToken, submitAnswer);
router.post('/end', verifyToken, endGame);
router.get('/history', verifyToken, getUserGames);

export default router;

