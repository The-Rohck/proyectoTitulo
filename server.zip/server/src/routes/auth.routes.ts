import { Router } from 'express';
import { register, login } from '../controllers/auth.controller';
import { isAdmin } from '../middlewares/isAdmin';

const router = Router();

// 🔹 Registro de usuarios normales
router.post('/register', (req, res, next) => {
  const { role } = req.body;

  if (role === 'admin') {
    // Si se quiere crear un admin, aplicar middleware
    return isAdmin(req, res, () => register(req, res));
  }

  // Registro normal
  return register(req, res);
});

// 🔹 Login
router.post('/login', login);

export default router;