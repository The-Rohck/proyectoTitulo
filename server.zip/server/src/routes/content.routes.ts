import express from 'express';
import {
  createContent,
  getContents,
  getContentById,
  updateContent,
  deleteContent,
} from '../controllers/content.controller';
import { verifyToken, isAdmin } from '../middlewares/auth.middleware';

const router = express.Router();

// Solo los administradores pueden crear, actualizar o eliminar
router.post('/', verifyToken, isAdmin, createContent);
router.get('/', getContents);
router.get('/:id', getContentById);
router.put('/:id', verifyToken, isAdmin, updateContent);
router.delete('/:id', verifyToken, isAdmin, deleteContent);

export default router;



