import express from 'express';
import {
  getPhrases,
  getPhraseById,
  createPhrase,
  updatePhrase,
  deletePhrase,
} from '../controllers/phrase.controller';
import { verifyToken, isAdmin } from '../middlewares/auth.middleware';

const router = express.Router();

// 📜 Listar y obtener frases (usuarios autenticados)
router.get('/', verifyToken, getPhrases);
router.get('/:id', verifyToken, getPhraseById);

// 🔒 Crear, actualizar y eliminar (solo administradores)
router.post('/', verifyToken, isAdmin, createPhrase);
router.put('/:id', verifyToken, isAdmin, updatePhrase);
router.delete('/:id', verifyToken, isAdmin, deletePhrase);

export default router;
