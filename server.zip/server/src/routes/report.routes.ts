import express from 'express';
import { verifyToken, isAdmin } from '../middlewares/auth.middleware';
import {
  getGeneralStats,
  getUserStats,
  getLeaderboard,
} from '../controllers/report.controller';

const router = express.Router();

// Solo admin ve estadísticas globales
router.get('/general', verifyToken, isAdmin, getGeneralStats);

// Usuario autenticado ve su desempeño
router.get('/user', verifyToken, getUserStats);

// Ranking global
router.get('/leaderboard', verifyToken, getLeaderboard);

export default router;
