import express from 'express';
import {
  getAllRelations,
  getRelationById,
  createRelation,
  updateRelation,
  deleteRelation,
} from '../controllers/synonymAntonym.controller';
import { verifyToken, isAdmin } from '../middlewares/auth.middleware';

const router = express.Router();

// 🧾 Públicos (para usuarios autenticados)
router.get('/', verifyToken, getAllRelations);
router.get('/:id', verifyToken, getRelationById);

// 🔒 Solo administradores
router.post('/', verifyToken, isAdmin, createRelation);
router.put('/:id', verifyToken, isAdmin, updateRelation);
router.delete('/:id', verifyToken, isAdmin, deleteRelation);

export default router;
