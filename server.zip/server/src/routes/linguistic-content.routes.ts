import express from 'express';
import {
  createLinguisticContent,
  getLinguisticContents,
  getLinguisticContentById,
  updateLinguisticContent,
  deleteLinguisticContent,
} from '../controllers/linguistic-content.controller';
import { verifyToken, isAdmin } from '../middlewares/auth.middleware';

const router = express.Router();

// CRUD protegido para admin
router.post('/', verifyToken, isAdmin, createLinguisticContent);
router.get('/', getLinguisticContents);
router.get('/:id', getLinguisticContentById);
router.put('/:id', verifyToken, isAdmin, updateLinguisticContent);
router.delete('/:id', verifyToken, isAdmin, deleteLinguisticContent);

export default router;
