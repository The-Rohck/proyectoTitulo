import express from 'express';
import { getProfile } from '../controllers/user.controller';
import { verifyToken } from '../middlewares/auth.middleware';

const router = express.Router();

router.get('/me', verifyToken, getProfile);

export default router;
