import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
dotenv.config();

import authRoutes from './routes/auth.routes';
import userRoutes from './routes/user.routes';
import contentRoutes from './routes/content.routes';
import gameRoutes from './routes/game.routes';
import reportRoutes from './routes/report.routes';
import phraseRoutes from './routes/phrase.routes';
import synonymAntonymRoutes from './routes/synonymAntonym.routes';
import wordRoutes from './routes/word.routes';
import linguisticContentRoutes from './routes/linguistic-content.routes';
import miniGameRoutes from './routes/miniGame.routes';

const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/mezcla_vocablos')
  .then(() => console.log('✅ Conectado a MongoDB'))
  .catch(err => console.error('❌ Error de conexión MongoDB:', err));

app.get('/', (_, res) => res.send('✅ API Mezcla Vocablos funcionando'));

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/content', contentRoutes);
app.use('/api/games', gameRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/phrases', phraseRoutes);
app.use('/api/relations', synonymAntonymRoutes);
app.use('/api/words', wordRoutes);
app.use('/api/linguistic-content', linguisticContentRoutes);
app.use('/api/mini-games', miniGameRoutes);

export default app;

