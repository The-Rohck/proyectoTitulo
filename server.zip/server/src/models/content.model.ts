import { Schema, model } from 'mongoose';

const ContentSchema = new Schema(
  {
    word: { type: String, required: true, trim: true },
    definition: { type: String, required: true },
    type: {
      type: String,
      enum: ['noun', 'verb', 'adjective', 'adverb', 'phrase'],
      default: 'noun',
    },
    language: { type: String, default: 'es' },
    examples: [{ type: String }],
    createdBy: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

export default model('Content', ContentSchema);
