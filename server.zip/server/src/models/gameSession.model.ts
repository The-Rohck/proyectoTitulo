import { Schema, model, models } from 'mongoose';

const LetterSchema = new Schema({
  wordId: { type: Schema.Types.ObjectId, ref: 'Word', required: true },
  letter: String,
  definition: String,
  correctAnswer: String,
  status: { type: String, enum: ['pending', 'correct', 'wrong'], default: 'pending' },
});

const GameSessionSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    score: { type: Number, default: 0 },
    timeLeft: { type: Number, default: 60 },
    letters: [LetterSchema],
    finished: { type: Boolean, default: false },
  },
  { timestamps: true }
);

export default models.GameSession || model('GameSession', GameSessionSchema);
