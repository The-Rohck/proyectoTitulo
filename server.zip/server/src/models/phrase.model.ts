import { Schema, model, models } from 'mongoose';

const PhraseSchema = new Schema(
  {
    text: { type: String, required: true },
    meaning: { type: String, required: true },
    difficulty: { type: String, enum: ['easy', 'medium', 'hard'], default: 'medium' },
    example: { type: String },
    author: { type: String },
  },
  { timestamps: true }
);

export default models.Phrase || model('Phrase', PhraseSchema);
