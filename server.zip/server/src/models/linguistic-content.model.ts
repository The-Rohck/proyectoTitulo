import { Schema, model } from 'mongoose';

const LinguisticContentSchema = new Schema(
  {
    baseWord: { type: String, required: true, trim: true },
    synonyms: [{ type: String }],
    antonyms: [{ type: String }],
    relatedPhrases: [{ type: String }],
    category: {
      type: String,
      enum: ['vocabulary', 'phrase', 'expression'],
      default: 'vocabulary',
    },
    difficulty: {
      type: String,
      enum: ['easy', 'medium', 'hard'],
      default: 'medium',
    },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

export default model('LinguisticContent', LinguisticContentSchema);
