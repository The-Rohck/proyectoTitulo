import { Schema, model } from 'mongoose';

const MiniGameSchema = new Schema(
  {
    name: { type: String, required: true },
    description: { type: String },
    type: {
      type: String,
      enum: ['mix_words', 'match_synonyms', 'match_antonyms', 'complete_phrase'],
      required: true,
    },
    difficulty: {
      type: String,
      enum: ['easy', 'medium', 'hard'],
      default: 'medium',
    },
    timeLimit: { type: Number, default: 60 },
    questions: [
      {
        question: String,
        options: [String],
        correctAnswer: String,
      },
    ],
    createdBy: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  { timestamps: true }
);

export default model('MiniGame', MiniGameSchema);
