import { Schema, model, models } from 'mongoose';

const SynonymAntonymSchema = new Schema(
  {
    baseWord: { type: String, required: true }, // palabra base
    synonyms: [{ type: String }], // lista de sinónimos
    antonyms: [{ type: String }], // lista de antónimos
    difficulty: {
      type: String,
      enum: ['easy', 'medium', 'hard'],
      default: 'medium',
    },
    createdBy: { type: String },
  },
  { timestamps: true }
);

export default models.SynonymAntonym || model('SynonymAntonym', SynonymAntonymSchema);

