import { Schema, model, models } from 'mongoose';

const WordSchema = new Schema(
  {
    term: { type: String, required: true, unique: true }, // palabra principal
    definition: { type: String, required: true },
    examples: [{ type: String }], // ejemplos opcionales
    partOfSpeech: {
      type: String,
      enum: ['sustantivo', 'verbo', 'adjetivo', 'adverbio', 'otros'],
      default: 'otros',
    },
    difficulty: {
      type: String,
      enum: ['easy', 'medium', 'hard'],
      default: 'medium',
    },
    topic: { type: String }, // opcional (ej: animales, emociones, etc.)
    createdBy: { type: String }, // referencia al creador o admin
  },
  { timestamps: true }
);

export default models.Word || model('Word', WordSchema);
