import { Schema, model, models } from 'mongoose';

const GameSchema = new Schema(
  {
    title: { type: String, required: true },
    description: { type: String, default: '' },
    type: { type: String, enum: ['principal', 'sinonimos', 'antonimos', 'frases'], default: 'principal' },
    questions: [
      {
        question: { type: String, required: true },
        correctAnswer: { type: Boolean, required: true },
      },
    ],
    active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

export default models.Game || model('Game', GameSchema);
